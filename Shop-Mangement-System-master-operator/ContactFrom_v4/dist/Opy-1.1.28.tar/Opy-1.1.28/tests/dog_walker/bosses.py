class NatureLover:              # Define a type of human being that loves nature
    def walk (self, dog):       # The NatureLover walks the dog, really
        print ('\nC\'mon!')     # \n means start on new line, \' means ' inside string
        dog.follow_me ()        # Just lets it escape

class CouchPotato:              # Define a type of human being that loves couchhanging
    def walk (self, dog):       # The CouchPotato walks the dog, well, lets it go
        print ('\nBugger off!') # \n means start on new line
        dog.escape ()           # Just lets it escape