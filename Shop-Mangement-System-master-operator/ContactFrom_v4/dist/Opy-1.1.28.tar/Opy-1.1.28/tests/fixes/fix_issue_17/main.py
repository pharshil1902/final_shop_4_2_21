#!/usr/bin/python

problemstring = b''
problemstring2 = b'hello'

print( problemstring )
print( problemstring2 )
