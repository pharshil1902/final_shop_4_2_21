#!/usr/bin/python
l1_opy_ = b''
ll_opy_ = b'hello'
print( l1_opy_ )
print( ll_opy_ )